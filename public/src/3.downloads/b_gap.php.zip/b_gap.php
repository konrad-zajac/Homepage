<?
function solution($ins_num)
	{
		$b_num = decbin($ins_num);
		preg_match_all('/([0]+|[1]+)/', $b_num, $chars); 
		
		$strlen_max = 0;
		for ($li = 0; $li < count($chars[0]); $li++)
		{
		 $chars[1][$li] = strlen($chars[0][$li]);
		    if (($chars[1][$li] > $strlen_max) && ($chars[0][$li][0] == '0') && ($chars[0][$li - 1][0] == '1'))
		    {
		    	if(isset($chars[0][$li + 1][0]))
		    	{
		    	$strlen_max = $chars[1][$li];	
		    	}
		   
		        
		    }
		}
		return $strlen_max;
	}