#include<iostream>
#include<cstdlib>
#include <ctime>
using namespace std;



int main()
{
    unsigned long long iterator=0,previous_value = 0, current_value = 1,inserted_number;
    
    std::cout << "Enter the count of fibonacci's numbers to display: ";
    std::cin >> inserted_number;
    clock_t begin = clock();

    
    for( iterator=0;iterator<inserted_number;iterator++)
    {
        cout<<current_value<<" ";
        current_value += previous_value;
        previous_value = current_value-previous_value;
    }
    clock_t end = clock();
    double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
    cout << "operation donde in " <<fixed<< elapsed_secs << " seconds";
    return 0;
}
