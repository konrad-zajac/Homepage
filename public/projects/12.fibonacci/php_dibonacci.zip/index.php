<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?
function getFib($n)
{
    return round(pow((sqrt(5)+1)/2, $n) / sqrt(5));
}

?>


</body>
</html>
