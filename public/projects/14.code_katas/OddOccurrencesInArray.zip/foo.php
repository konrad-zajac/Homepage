<?
function solution($A)
{
		if (count($A) == 1)
		{
			return $A[0];
		}
		else
		{

		//while (list(, $value_first) = each($A))
			 	foreach ($A as $value_first)
		 {
		 	$special = 0;
		 	$repeat = 0;
		 	foreach ($A as $value_second)
			{
			    if($value_first == $value_second)
			    {
			    	$repeat++;
			    }		   
			}
			if($repeat == 1)
		    {
		       return (int)$value_first;
		    }
		}
	}
}