#include <stdio.h>
#include <string.h>
#include <time.h>


int main()
{
	int inserted_number, cheked_number, is_divisible;
    printf("Enter the value in which to find prime numbers:");
    scanf("%d", &inserted_number);
    printf("%d", inserted_number);
clock_t start, end;
double cpu_time_used;
start = clock();
     for( cheked_number = 2; cheked_number < inserted_number; cheked_number = cheked_number + 1 ){
      is_divisible=0;
      for (int potential_dividers=2; potential_dividers<inserted_number; potential_dividers = potential_dividers + 1)
       {
       	if  (cheked_number % potential_dividers == 0 )
            {
                is_divisible = is_divisible + 1;
                
             }

       }
 if (is_divisible == 1)
     {
     	  char str[128];
     	strcpy (str,"number ");
     	char istr[128];
sprintf(istr, "%d", cheked_number);

  strcat (str,istr);
  strcat (str," is prime");
    puts (str);

    }

   }
   end = clock();
cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
		char time1_str[128];
		strcpy (time1_str,"operation done in ");

     	    char time2_str[128];

     	snprintf(time2_str, 128, "%f", cpu_time_used);
     	  strcat (time1_str,time2_str);
          strcat (time1_str," seconds");


		puts(time1_str);
       return 0;

}
  