
#!/bin/bash
echo "Enter the number to which count primes"
read entered_number;
start=`date +%s`
for((checked_number=2;checked_number<=entered_number;checked_number++))
do
let is_dividible=0;
	for((possible_dividers=2;possible_dividers<=entered_number;possible_dividers++))
		do
			if [ `echo "$checked_number % $possible_dividers" | bc` -eq 0 ]
			then
			((is_dividible++))
			fi
		done
	if [[ $is_dividible == 1 ]]
	then
	echo $checked_number;
	fi

done
end=`date +%s`

runtime=$((end-start))
	echo $runtime
#		then
#		let $is_dividible = $is_dividible + 1;
#		fi
#	done
