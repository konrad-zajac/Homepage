<?
function dont_give_me_five($start, $end) {
    $count = 0;
    for ($i = $start;$i<=$end;$i++) {
        if (strpos($i, '5') !== false) {
            continue;
        }
            $count++;
    }
    return $count;
  }