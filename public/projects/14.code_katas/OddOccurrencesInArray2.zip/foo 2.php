<?
function solution($A)
{
	$array=array_count_values($A);
	foreach($array as $k=>$v){
		if($v==1){
			return (int)$k;
		}
	}
}