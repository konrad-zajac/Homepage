<?  
    function toRoman($arabic_number) {
        $interchangeable_roman_arr = array
        (
        'M' => 1000,
        'CM' => 900,
        'D' => 500,
        'CD' => 400,
        'C' => 100,
        'XC' => 90,
        'L' => 50,
        'XL' => 40,
        'X' => 10,
        'IX' => 9,
        'V' => 5,
        'IV' => 4,
        'I' => 1
        );
        $returnValue = '';
        while ($arabic_number > 0) {
            foreach ($interchangeable_roman_arr as $roman => $int) {
                echo "ar =".$arabic_number."int = ".$int. ">= ".($arabic_number >= $int)."</br>";
                if($arabic_number >= $int) {
                    $arabic_number -= $int;
                    $returnValue .= $roman;
                    break;
                }
            }
        }
        return $returnValue;
    }