//
//  main.cpp
//  perwszw
//
//  Created by Konrad Zajac on 19/11/2016.
//  Copyright © 2016 Konrad Zajac. All rights reserved.
//

#include <iostream>
#include <ctime>
#include <string>


using namespace std;

    int main(int argc, const char * argv[])
    {
        int inserted_number;
        std::cout << "Enter the value in which to find prime numbers: ";
        std::cin >> inserted_number;
        clock_t begin = clock();
        for (int cheked_number=2; cheked_number<=inserted_number; cheked_number++)
        {
            int is_divisible = 0;

            for (int potential_dividers=2; potential_dividers<inserted_number; potential_dividers++)
            {
                
            if (cheked_number % potential_dividers == 0 )
                {
                    is_divisible += 1;
                    
                }
                
               
            }
        if (is_divisible == 1)
        {
            cout << cheked_number<<'\n';
        }

        }
        clock_t end = clock();
        double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
        cout << "operation donde" << elapsed_secs << " in";
        return 0;
    }
