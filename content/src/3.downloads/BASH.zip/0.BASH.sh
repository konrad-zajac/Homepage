#!/bin/bash

source LIB.sh 

function print_help {
	Select the number
}

function main {

echo "   **************************************************"
echo "   * [0] - CHANGE THE NAME                          *" 
echo "   * [9] - MAC OPERATIONS                           *" 
echo "   * [8] - IMAGE MANIPULATION[REQUIRES IMAGE MAGIC] *" 
echo "   * [7] - CREATE                   				  *" 
echo "   ********************************"
echo "select one from the above"
read main_choice
case "$main_choice" in 
	"0") name_operations ;;
	"9") mac_operations ;;	
	"8") image_operations;;	
	"7") make_f_and_f;;	
	"*") kill -SIGINT $$
esac
	
echo "Operation done"
	echo "[0] - run again"
	echo "[9] - delete the app"
	read end_choice
	case "$end_choice" in
	"0") run_again ;;
	"9") self_destruct ;;
	"*") kill -SIGINT $$
esac
					
}
main $@
