
import java.util.Scanner;
public class prime {
int x = 0;
   public static void main(String args[]) {
      System.out.println("enter the number to which find primes");
        int inserted_number = new Scanner(System.in).nextInt();
		long startTime = System.nanoTime();
       for(int checked_number = 0; checked_number<inserted_number; ++checked_number)
       {
	   int is_dividible = 0;
	   for (int possible_dividers = 2;possible_dividers<=inserted_number;possible_dividers++)
		   {
			   if(checked_number % possible_dividers == 0)
			   {
				   is_dividible += 1;
			   }
		   }
		   if(is_dividible == 1)
		   {
        System.out.println("the number " + checked_number + " is prime");
		   }
       }
	   long estimatedTime = System.nanoTime() - startTime;
	   double seconds = (double)estimatedTime / 1000000000.0;
      System.out.println("Operation done in " + seconds);

      }
}



