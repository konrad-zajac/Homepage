
<?
 function accum($a) {
   $array = str_split($a);
   $strlen = strlen($a);
   $str = "";
  for ($i = 0; $i < $strlen   ; ++$i) {
    if ( $i == 0 )
    {
      $str .= strtoupper($array[$i])."-";
      continue;
    }
    elseif( $i == $strlen - 1)
    {
      $str .= strtoupper($array[$i]).str_repeat(strtolower($array[$i]),$i);
      continue;
    }
      $str .= strtoupper($array[$i]).str_repeat(strtolower($array[$i]),$i )."-";
  }  
  return $str;
 } 
