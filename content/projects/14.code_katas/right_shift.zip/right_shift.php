<?
function right_shift($A = [], $K)
	{
		if(empty($A))
	{
		return NULL;
	}
	else{
		for($i=0; $i < $K ; ++$i)
		{
		$last = array_pop($A);
		array_unshift($A, $last);
		}
		return $A;
	}
}
