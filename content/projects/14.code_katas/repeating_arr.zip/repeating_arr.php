<?
function repeating_arr($array){
	
$previous = '';
foreach ($array as $value)
{

echo "<tr>";
if  ($previous ==  $value['a'])
{
echo "<td>&nbsp</td>";
}
else
{
    echo "<td>".$value['a'].'</td>'; 
}   

echo "<td>".$value['b'].'</td>';
echo "</tr>";
$previous = $value['a'];
}
}	
