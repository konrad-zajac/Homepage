#!/usr/bin/python
import time

x=input('podaj zakres w ktorym znalezc liczby pierwsze\n')
t0 = time.clock()
aList = [];
for i in range(2,x):
    f=0
    jest_podzielna=0
    for ii in range(2,50):
        if i%ii==0: 
            f += 1
    if f==1:
        aList.append(i)
print aList
print  "wykonano ",time.clock()," w sekund"
