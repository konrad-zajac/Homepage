#!/usr/bin/python
import time

x=input('podaj zakres w ktorym znalezc liczby pierwsze\n')
t0 = time.clock()
for i in range(2,x):
    jest_podzielna=0
    for ii in range(2,x):
        if i%ii==0: 
            jest_podzielna += 1
    if jest_podzielna==1:
        print i, 'jest liczba pierwsza'
print  "wykonano ",time.clock()," w sekund"
