
function string_adding_questions
{
		echo -e "[0->0]===========================\nWhat to add?"
        read what
        echo -e "where?\n[0] - to the front of the word\n[9] - to the back of the word with extension\n[8] - to the back of the word"
        read where
}