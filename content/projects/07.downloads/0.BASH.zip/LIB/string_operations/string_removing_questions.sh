
function string_removing_questions
{
        echo -e "[0->9]===========================\nWhat to remove?"
            echo "[0] - number (chars from front)"
            echo "[9] - string"
                read removing_choice

}