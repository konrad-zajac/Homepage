
function mod_choice
{
        echo -e "[0->8]===========================\nSelct a modification\n[0] Modify strings\n[9] Rename files from [0,1] to N"
        read modifying_choice
}