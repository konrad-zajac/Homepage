function so_questions
{
    echo -e "[0]==============================\nadd, remove, or modify  string?\n[0] Add\n[9] Remove\n[8] Modify\n[Q] Quit"
    	read string_choice
}