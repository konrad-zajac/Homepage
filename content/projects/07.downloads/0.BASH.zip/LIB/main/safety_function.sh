function safety_function
{
	if [ "$f" == "0.BASH.sh" ] || [ "$f" ==  "LIB" ]
                    then
                    continue
                    fi
}