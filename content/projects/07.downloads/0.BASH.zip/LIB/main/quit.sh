function quit
{
	kill -SIGINT $$
}