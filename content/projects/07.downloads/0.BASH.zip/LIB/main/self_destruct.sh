function self_destruct
{
	rm 0.BASH.sh
	rm LIB.sh
}