function run_again
{
	./$0
}