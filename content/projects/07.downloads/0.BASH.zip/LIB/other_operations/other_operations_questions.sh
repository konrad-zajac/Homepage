function other_operations_questions
{
    echo -e "[7]==============================\nWhat kind of operation?\n[H,h] Help\n[0] Convert mov to mp4\n[9] Delete everything else\n[R] Run again\n[Q] Quit"
    read oo_choice
}