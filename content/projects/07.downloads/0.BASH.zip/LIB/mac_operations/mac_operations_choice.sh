
function mac_operations_choice
{
echo -e "what mac operation would you like to do?\n[0] Make the dock hide delay 0\n[9] change the path for screen shots\n[8] Toggle hidden files\n[Q] Quit"
    read mac_choice
}
