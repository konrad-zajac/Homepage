
function main_io_choice
{
echo -e "what to do with the photo?\n[9] - merge\n[8] - crop one image\n[Q] - Quit"
#\n[0] - crop photo albums
#\n[7] - crop many images
        read image_choice
}