
function image_crop_choice
{
          echo -e "crop images or albums?\n[0] - crop images\n[9] - crop photo albums"
                read image_choice
}