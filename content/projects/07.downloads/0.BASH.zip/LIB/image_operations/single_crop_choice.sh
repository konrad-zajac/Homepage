function image_crop_choice	
{
echo -e "how many?\n[0] - one\n[9] - more"
read image_count
}