
function merge_horizontally
{
   convert 1.$ext 2.$ext -append $result_name.$ext;
                open $result_name.$ext

}