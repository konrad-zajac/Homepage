#01 add_string 11
#02 remove_string 54
#03 hidden_files 79
#04 make_f_and_f 101
#05
#06
#07
#08
#09
#010
function add_string
{
	echo "what?"
	read what
	echo "where?"
	echo "[0] - to the front of the word"
	echo "[9] - to the back of the word"
	read where


		if [ "$where" == "0" ]
		then
			for f in *
			do
				#safety-----------------
				if [ "$f" == "0.BASH.sh" ]
				then
				continue
				fi
				#safety-----------------

			mv "$f" "$what${f}"

		done

	elif [ "$where" == "9" ]
	then
		for f in *
			do
					#safety-----------------
					if [ "$f" == "0.BASH.sh" ]
					then
					continue
					fi
					#safety-----------------

				mv "$f" "${f}$what"
			done
		fi

}
#------------------------------
#------------------------------
function remove_string
{

	echo "What string to remove?"
	read string_to_remove
#	if [ -z ${string_to_remove+x} ]
#		then
#		echo "no"
#	else
	for f in *
	do
				#safety-----------------
				if [ "$f" == "0.BASH.sh" ]
				then
				continue
				fi
				#safety-----------------
		mv -i  "$f" "$(echo $f | sed "s/$string_to_remove//g")"
	done
#	fi

}
#------------------------------
#------------------------------

function hidden_files 
{
		
echo "[0] - show "
echo "[9] - hide "
read view_choice

		if [[ $view_choice == 0 ]]
		then
			defaults write com.apple.finder AppleShowAllFiles YES
			killall Finder
			killall Terminal
		elif  [[ $view_choice == 9 ]] 
		then
			defaults write com.apple.finder AppleShowAllFiles NO
			killall Finder
			killall Terminal
		fi
}
#------------------------------
#------------------------------

function make_f_n_f
{
	 
		echo "what?"
		echo "files[0]"
		echo "folders[9]"
		read making_choice
		if [[ $making_choice == 0 ]]
			then
echo "how many?"
read count
echo "what extension?"
read extension

	for ((c=0; c<=$count; c++))
	do	

		if [ "$c" -le 9 ]
		then
		touch 0$c.$extension
		continue
		fi


	touch $c.$extension

	done
		elif [[ $making_choice == 9 ]]
			then
echo "how many?"
read count

	for ((c=0; c<=$count; c++))
	do	

		if [ "$c" -le 9 ]
		then
		touch 0$c
		continue
		fi


	touch $c

	done
		fi

}
#------------------------------
#------------------------------



function move_files	
{
	
	echo "move all to front or to the back?"
	echo "[0] - front "
	echo "[1] - back"
	echo "[2] - wejsc do kazdego katalogu i wyjac wszystko"
	echo "[3] - jeden plik skopiowac i wsadzic do kazdego katalogu"

	read moving_choice
	if [[ $moving_choice == 0 ]]
	then

	echo "to what folder?"
	read to_what_folder
	echo "which files?"
	read which_files

	echo $to_what_folder | xargs -n 1 mv $which_files
	
	elif [[ $moving_choice == 2  ]]
	then
	find . -type f ! -name 0.BASH.sh -exec mv {} ./ \;
	
	fi
}
