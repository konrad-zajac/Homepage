#!/bin/bash

source common.sh

function print_help {
	Select the number
}

function main {

echo "   ********************************"
echo "   * [0] - MAKE                   *" 
echo "   * [1] - ADD TO THE NAME        *" 
echo "   * [2] - SHOW HIDDEN FILES [MAC]*" 
echo "   ********************************"
echo "select one from the above"
read main_choice

	if [[ $main_choice == 0 ]]
	then
		make_f_n_f	
	elif [[ $main_choice == 1 ]]
	then
		add_string
	elif [[ $main_choice == 2 ]]
	then
		hidden_files
#	echo "add or remove string?"
#		echo "[0] ADD"
#		echo "[9] REMOVE"
#		read string_choice
#			if [[ $string_choice == 0 ]]
#		elif [[ $string_choice == 9 ]]
#		then
#		remove_string
##			then
#	elif [[ $main_choice == 5 ]]
#	then
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
#	elif [[ $main_choice == 4 ]]
#	then
#		remove_spaces	
	else
		kill -SIGINT $$
	fi
}
main $@
